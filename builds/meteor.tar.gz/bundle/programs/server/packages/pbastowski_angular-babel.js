(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['pbastowski:angular-babel'] = {};

})();

//# sourceMappingURL=pbastowski_angular-babel.js.map
