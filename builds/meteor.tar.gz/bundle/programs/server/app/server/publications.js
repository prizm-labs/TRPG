(function(){Meteor.publish('Projects', function () {
  return Projects.find({});
});

Meteor.publish('Tasks', function () {
  return Tasks.find({});
});

Projects.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});

Tasks.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
}).call(this);

//# sourceMappingURL=publications.js.map
