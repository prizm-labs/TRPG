(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/actor.coffee.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Action, ActionTypes, Actor, ActorTypes, Effect, Grid, MovementAction, Roll, Session, Tile, TurnTracker,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                         //
                                                                       //
Roll = function(dieCount, dieType) {                                   // 1
  var count, i, ref, roll, rolls, sum;                                 // 2
  sum = 0;                                                             // 2
  rolls = [];                                                          // 2
  for (count = i = 0, ref = dieCount; 0 <= ref ? i < ref : i > ref; count = 0 <= ref ? ++i : --i) {
    roll = Math.floor(Math.random() * dieType) + 1;                    // 5
    rolls.push(roll);                                                  // 5
    sum += roll;                                                       // 5
  }                                                                    // 4
  console.log(rolls);                                                  // 2
  return sum;                                                          // 9
};                                                                     // 1
                                                                       //
ActorTypes = {                                                         // 1
  player: 0,                                                           // 12
  playerAlly: 1,                                                       // 12
  enemy: 2,                                                            // 12
  ally: 3,                                                             // 12
  neutral: 4                                                           // 12
};                                                                     //
                                                                       //
ActionTypes = {                                                        // 1
  normal: 0,                                                           // 19
  bonus: 1,                                                            // 19
  reaction: 2,                                                         // 19
  movement: 3                                                          // 19
};                                                                     //
                                                                       //
this.ActionTypes = ActionTypes;                                        // 1
                                                                       //
this.ActorTypes = ActorTypes;                                          // 1
                                                                       //
Effect = (function() {                                                 // 1
  Effect.prototype.valueGenerators = [];                               // 28
                                                                       //
  Effect.prototype.defenses = [];                                      // 28
                                                                       //
  Effect.prototype.lastValue = null;                                   // 28
                                                                       //
  Effect.prototype.type = null;                                        // 28
                                                                       //
  Effect.prototype.subtype = null;                                     // 28
                                                                       //
  Effect.prototype.description = "";                                   // 28
                                                                       //
  function Effect(valueGenerators, type, subtype, description, defenses) {
    this.valueGenerators = valueGenerators;                            // 36
    this.type = type;                                                  // 36
    this.subtype = subtype;                                            // 36
    this.description = description;                                    // 36
    this.defenses = defenses;                                          // 36
  }                                                                    //
                                                                       //
  Effect.prototype.presentResolution = function(value) {               // 28
    return this.lastValue = value;                                     //
  };                                                                   //
                                                                       //
  Effect.prototype.resolve = function(modifier, multiplier) {          // 28
    this.lastValue = 0;                                                // 49
    _.each(this.valueGenerators, (function(_this) {                    // 49
      return function(vg) {                                            //
        console.log(vg);                                               // 52
        _this.lastValue += Roll(vg.dieCount, vg.dieType) + vg.modifier;
        return console.log(_this.lastValue);                           //
      };                                                               //
    })(this));                                                         //
    return this.lastValue;                                             // 58
  };                                                                   //
                                                                       //
  return Effect;                                                       //
                                                                       //
})();                                                                  //
                                                                       //
Action = (function() {                                                 // 1
  Action.prototype.effects = [];                                       // 61
                                                                       //
  Action.prototype.range = 0;                                          // 61
                                                                       //
  Action.prototype.type = null;                                        // 61
                                                                       //
  Action.prototype.description = "";                                   // 61
                                                                       //
  Action.prototype.target = null;                                      // 61
                                                                       //
  Action.prototype.targetType = null;                                  // 61
                                                                       //
  Action.prototype.duration = 6;                                       // 61
                                                                       //
  Action.prototype.actor = null;                                       // 61
                                                                       //
  function Action(effects, range, targeting, type, description) {      // 70
    this.effects = effects;                                            // 71
    this.range = range;                                                // 71
    this.type = type;                                                  // 71
    this.description = description;                                    // 71
  }                                                                    //
                                                                       //
  Action.prototype.showTargetRange = function() {};                    // 61
                                                                       //
  Action.prototype.areaOfEffect = function() {                         // 61
    return 1;                                                          //
  };                                                                   //
                                                                       //
  Action.prototype.setTarget = function(target) {                      // 61
    return this.target = target;                                       //
  };                                                                   //
                                                                       //
  Action.prototype.resolve = function() {                              // 61
    var resolveDamage;                                                 // 88
    resolveDamage = function(effect) {                                 // 88
      console.log(this.target.hitPoints);                              // 89
      this.target.hitPoints -= effect.resolve();                       // 89
      return console.log(this.target.hitPoints);                       //
    };                                                                 //
    return _.each(this.effects, (function(_this) {                     //
      return function(effect) {                                        //
        switch (effect.type) {                                         // 94
          case "damage":                                               // 94
            return resolveDamage.call(_this, effect);                  //
          default:                                                     // 94
            return null;                                               //
        }                                                              // 94
      };                                                               //
    })(this));                                                         //
  };                                                                   //
                                                                       //
  return Action;                                                       //
                                                                       //
})();                                                                  //
                                                                       //
MovementAction = (function(superClass) {                               // 1
  extend(MovementAction, superClass);                                  // 103
                                                                       //
  function MovementAction(range) {                                     // 103
    MovementAction.__super__.constructor.call(this, [], range, 1, ActionTypes.movement, "Move character at regular speed");
  }                                                                    //
                                                                       //
  MovementAction.prototype.setRange = function(range) {                // 103
    return this.range = range;                                         //
  };                                                                   //
                                                                       //
  MovementAction.prototype.showTargetRange = function() {              // 103
    var origin, range;                                                 // 111
    origin = [this.actor.currentTile.x, this.actor.currentTile.y];     // 111
    return range = this.actor.grid["return"](this.actor.grid.getRangeAroundCoordinate(origin[0], origin[1]));
  };                                                                   //
                                                                       //
  MovementAction.prototype.setTarget = function() {};                  // 103
                                                                       //
  MovementAction.prototype.resolve = function() {};                    // 103
                                                                       //
  return MovementAction;                                               //
                                                                       //
})(Action);                                                            //
                                                                       //
Grid = (function() {                                                   // 1
  Grid.prototype.tileWidth = 0;                                        // 123
                                                                       //
  Grid.prototype.tileHeight = 0;                                       // 123
                                                                       //
  Grid.prototype.tileUnit = 0;                                         // 123
                                                                       //
  Grid.prototype.tiles = [];                                           // 123
                                                                       //
  function Grid(tileType, tileUnit, heightByTile, widthByTile) {       // 128
    var generateHexGrid, generateSquareGrid;                           // 130
    this.tileUnit = tileUnit;                                          // 130
    generateSquareGrid = function(tiles) {                             // 130
      var i, ref, results, x, y;                                       // 133
      this.tileWidth = tileUnit;                                       // 133
      this.tileHeight = tileUnit;                                      // 133
      results = [];                                                    // 136
      for (x = i = 0, ref = widthByTile; 0 <= ref ? i < ref : i > ref; x = 0 <= ref ? ++i : --i) {
        results.push((function() {                                     // 137
          var j, ref1, results1;                                       //
          results1 = [];                                               // 137
          for (y = j = 0, ref1 = heightByTile; 0 <= ref1 ? j < ref1 : j > ref1; y = 0 <= ref1 ? ++j : --j) {
            results1.push(tiles.push(new Tile(x, y)));                 // 138
          }                                                            // 137
          return results1;                                             //
        })());                                                         //
      }                                                                // 136
      return results;                                                  //
    };                                                                 //
    generateHexGrid = function(tiles) {};                              // 130
    switch (tileType) {                                                // 142
      case "square":                                                   // 142
        generateSquareGrid(this.tiles);                                // 143
        break;                                                         // 143
      case "hex":                                                      // 142
        generateHexGrid(this.tiles);                                   // 144
    }                                                                  // 142
  }                                                                    //
                                                                       //
  Grid.prototype.getTile = function(x, y) {                            // 123
    return _.findWhere(this.tiles, {                                   //
      x: x,                                                            // 148
      y: y                                                             // 148
    });                                                                //
  };                                                                   //
                                                                       //
  Grid.prototype.getRangeByTile = function(speed) {                    // 123
    return speed / this.tileUnit;                                      //
  };                                                                   //
                                                                       //
  Grid.prototype.getRangeAroundCoordinate = function(x, y, range) {    // 123
    var conjugates, coordinates, getAllConjugatesAtRange, i, j, k, len, len1, move, origin, pair, r, ref, target, translations;
    coordinates = [];                                                  // 154
    conjugates = [];                                                   // 154
    origin = [x, y];                                                   // 154
    getAllConjugatesAtRange = function(range) {                        // 154
      var difference;                                                  // 161
      difference = 0;                                                  // 161
      conjugates = [];                                                 // 161
      while (difference < range) {                                     // 163
        conjugates.push([range - difference, difference]);             // 164
        if (difference !== range - difference) {                       // 165
          conjugates.push([difference, range - difference]);           // 165
        }                                                              //
        difference++;                                                  // 164
      }                                                                //
      return conjugates;                                               // 168
    };                                                                 //
    for (r = i = 0, ref = range; 0 <= ref ? i < ref : i > ref; r = 0 <= ref ? ++i : --i) {
      conjugates = conjugates.concat(getAllConjugatesAtRange(r + 1));  // 171
    }                                                                  // 170
    translations = [];                                                 // 154
    for (j = 0, len = conjugates.length; j < len; j++) {               // 175
      pair = conjugates[j];                                            //
      translations.push(pair);                                         // 176
      if (pair[0] !== 0) {                                             // 177
        translations.push([-pair[0], pair[1]]);                        // 177
      }                                                                //
      if (pair[1] !== 0 && pair[0] !== 0) {                            // 178
        translations.push([-pair[0], -pair[1]]);                       // 178
      }                                                                //
      if (pair[1] !== 0) {                                             // 179
        translations.push([pair[0], -pair[1]]);                        // 179
      }                                                                //
    }                                                                  // 175
    console.log(translations);                                         // 154
    for (k = 0, len1 = translations.length; k < len1; k++) {           // 183
      move = translations[k];                                          //
      target = [origin[0] + move[0], origin[1] + move[1]];             // 184
      if (target[0] >= 0 && target[1] >= 0) {                          // 185
        coordinates.push(target);                                      // 185
      }                                                                //
    }                                                                  // 183
    console.log(coordinates);                                          // 154
    return coordinates;                                                // 192
  };                                                                   //
                                                                       //
  return Grid;                                                         //
                                                                       //
})();                                                                  //
                                                                       //
Tile = (function() {                                                   // 1
  Tile.prototype.x = null;                                             // 196
                                                                       //
  Tile.prototype.y = null;                                             // 196
                                                                       //
  function Tile(x, y) {                                                // 198
    this.x = x;                                                        // 199
    this.y = y;                                                        // 199
  }                                                                    //
                                                                       //
  return Tile;                                                         //
                                                                       //
})();                                                                  //
                                                                       //
Actor = (function() {                                                  // 1
  Actor.prototype.type = null;                                         // 204
                                                                       //
  Actor.prototype.initiative = 0;                                      // 204
                                                                       //
  Actor.prototype.movementSpeed = 0;                                   // 204
                                                                       //
  Actor.prototype.availableMovement = 0;                               // 204
                                                                       //
  Actor.prototype.hitPoints = 0;                                       // 204
                                                                       //
  Actor.prototype.name = null;                                         // 204
                                                                       //
  Actor.prototype.currentMap = null;                                   // 204
                                                                       //
  Actor.prototype.currentTile = null;                                  // 204
                                                                       //
  Actor.prototype.grid = null;                                         // 204
                                                                       //
  Actor.prototype.sizeX = 0;                                           // 204
                                                                       //
  Actor.prototype.sizeY = 0;                                           // 204
                                                                       //
  Actor.prototype.actions = {};                                        // 204
                                                                       //
  Actor.prototype.stats = {};                                          // 204
                                                                       //
  Actor.prototype.currentAction = null;                                // 204
                                                                       //
  function Actor(name, movementSpeed, hitPoints, type, stats) {        // 220
    this.type = type;                                                  // 221
    this.name = name;                                                  // 221
    this.movementSpeed = movementSpeed;                                // 221
    this.availableMovement = movementSpeed;                            // 221
    this.hitPoints = hitPoints;                                        // 221
    this.stats = stats;                                                // 221
  }                                                                    //
                                                                       //
  Actor.prototype.info = function() {                                  // 204
    return console.log(this.name, this.movementSpeed);                 //
  };                                                                   //
                                                                       //
  Actor.prototype.setMapCoordinate = function(x, y) {                  // 204
    return this.currentTile = this.grid.getTile(x, y);                 //
  };                                                                   //
                                                                       //
  Actor.prototype.setIntiative = function(value) {                     // 204
    return this.initiative = value;                                    //
  };                                                                   //
                                                                       //
  Actor.prototype.addAction = function(key, action) {                  // 204
    var _action;                                                       // 238
    _action = _.clone(action, true);                                   // 238
    this.actions[key] = _action;                                       // 238
    return _action.actor = this;                                       //
  };                                                                   //
                                                                       //
  Actor.prototype.selectAction = function(key) {                       // 204
    if (this.actions[key]) {                                           // 243
      return this.currentAction = this.actions[key];                   //
    }                                                                  //
  };                                                                   //
                                                                       //
  Actor.prototype.unselectAction = function() {                        // 204
    return this.currentAction = null;                                  //
  };                                                                   //
                                                                       //
  Actor.prototype.showActions = function() {                           // 204
    return _.each(this.actions, function(action) {                     //
      return console.log(action.description);                          //
    });                                                                //
  };                                                                   //
                                                                       //
  Actor.prototype.randomizeInitiative = function() {                   // 204
    return this.setIntiative(Roll(1, 20));                             //
  };                                                                   //
                                                                       //
  return Actor;                                                        //
                                                                       //
})();                                                                  //
                                                                       //
TurnTracker = (function() {                                            // 1
  function TurnTracker(type1) {                                        // 257
    this.type = type1;                                                 // 257
  }                                                                    //
                                                                       //
  TurnTracker.prototype.currentTurn = null;                            // 257
                                                                       //
  TurnTracker.prototype.currentParticipantIndex = null;                // 257
                                                                       //
  TurnTracker.prototype.currentParticipant = null;                     // 257
                                                                       //
  TurnTracker.prototype.totalTurns = 0;                                // 257
                                                                       //
  TurnTracker.prototype.turnOrder = [];                                // 257
                                                                       //
  TurnTracker.prototype.participants = [];                             // 257
                                                                       //
  TurnTracker.prototype.addParticipant = function(participant) {       // 257
    return this.participants.push(participant);                        //
  };                                                                   //
                                                                       //
  TurnTracker.prototype.advanceTurn = function() {                     // 257
    if (this.totalTurns === 0) {                                       // 271
      this.currentParticipantIndex = 0;                                // 272
      this.currentTurn = 1;                                            // 272
    } else {                                                           //
      this.currentParticipantIndex += 1;                               // 275
      this.currentTurn += 1;                                           // 275
      if (this.currentParticipantIndex >= this.participants.length) {  // 278
        this.currentParticipantIndex = 0;                              // 279
      }                                                                //
    }                                                                  //
    this.totalTurns += 1;                                              // 271
    this.currentParticipant = this.turnOrder[this.currentParticipantIndex];
    return console.log(this.currentParticipant);                       //
  };                                                                   //
                                                                       //
  TurnTracker.prototype.begin = function() {                           // 257
    this.sortByInitiative();                                           // 287
    return this.advanceTurn();                                         //
  };                                                                   //
                                                                       //
  TurnTracker.prototype.sortByInitiative = function() {                // 257
    this.turnOrder = _.sortBy(this.participants, function(p) {         // 291
      return -p.initiative;                                            // 292
    });                                                                //
    return console.log(this.turnOrder);                                //
  };                                                                   //
                                                                       //
  return TurnTracker;                                                  //
                                                                       //
})();                                                                  //
                                                                       //
Session = (function() {                                                // 1
  function Session() {}                                                // 298
                                                                       //
  return Session;                                                      //
                                                                       //
})();                                                                  //
                                                                       //
this.Grid = Grid;                                                      // 1
                                                                       //
this.Actor = Actor;                                                    // 1
                                                                       //
this.TurnTracker = TurnTracker;                                        // 1
                                                                       //
this.Effect = Effect;                                                  // 1
                                                                       //
this.Action = Action;                                                  // 1
                                                                       //
this.MovementAction = MovementAction;                                  // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=actor.coffee.js.map
