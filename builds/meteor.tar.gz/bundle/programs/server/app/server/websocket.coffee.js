(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/websocket.coffee.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var app, express, http, httpServer, io, port, server;                  // 1
                                                                       //
express = Meteor.npmRequire('express');                                // 1
                                                                       //
http = Meteor.npmRequire('http');                                      // 1
                                                                       //
io = Meteor.npmRequire('socket.io');                                   // 1
                                                                       //
port = 6666;                                                           // 1
                                                                       //
app = express();                                                       // 1
                                                                       //
app.use(function(req, res, next) {                                     // 1
  res.header("Access-Control-Allow-Origin", "*:5000");                 // 9
  res.header("Access-Control-Allow-Headers", "X-Requested-With");      // 9
  res.header("Access-Control-Allow-Headers", "Content-Type");          // 9
  res.header("Access-Control-Allow-Methods", "PUT, GET, POST, DELETE, OPTIONS");
  return next();                                                       //
});                                                                    // 8
                                                                       //
httpServer = http.createServer(app);                                   // 1
                                                                       //
server = io(httpServer, {                                              // 1
  origins: '*:5000'                                                    // 16
});                                                                    //
                                                                       //
this.numUsers = 0;                                                     // 1
                                                                       //
server.on('connection', this.ONCONNECTION.bind(this));                 // 1
                                                                       //
httpServer.listen(port);                                               // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=websocket.coffee.js.map
