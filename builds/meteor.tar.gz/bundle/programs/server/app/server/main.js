(function(){//not used
Meteor.startup(function () {
  var masterJson = JSON.parse(Assets.getText("trpg.json"));
});

Meteor.methods({
  'getHelloWorld': function getHelloWorld() {
    console.log("Hello world from the the meteor server!");
    return "Hello world from meteor server!";
  },
  'getSpellsData': function getSpellsData() {
    //hardcoded to get the first actor for now
    var masterJson = JSON.parse(Assets.getText("trpg.json"));
    return masterJson.actors[0].actions;
  }

});
}).call(this);

//# sourceMappingURL=main.js.map
