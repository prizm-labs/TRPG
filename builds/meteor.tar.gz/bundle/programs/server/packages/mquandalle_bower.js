(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mquandalle:bower'] = {};

})();

//# sourceMappingURL=mquandalle_bower.js.map
