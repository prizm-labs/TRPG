(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.coffee.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  invite: function(data) {                                             // 2
    console.log("testMeteorCall:", data);                              // 3
    return data + " echo";                                             // 4
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.coffee.js.map
