(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/main.coffee.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var burningHandsAction, burningHandsEffect, enemy, enemy2, enemy3, greatswordAction, greatswordDamageEffect, grid, magicMissileAction, magicMissleEffect, movementAction, player, player2, player3, tracker;
                                                                       //
grid = new Grid("square", 5, 5, 20, 20);                               // 2
                                                                       //
grid.getRangeAroundCoordinate(0, 0, 2);                                // 2
                                                                       //
grid.getRangeAroundCoordinate(2, 2, 2);                                // 2
                                                                       //
tracker = new TurnTracker();                                           // 2
                                                                       //
console.log(tracker.participants);                                     // 2
                                                                       //
player = new Actor("fighter", 40, 12, ActorTypes.player, {             // 2
  STR: 2,                                                              // 15
  DEX: 3,                                                              // 15
  CON: 2,                                                              // 15
  INT: 0,                                                              // 15
  WIS: 1,                                                              // 15
  CHA: -1                                                              // 15
}, {});                                                                //
                                                                       //
player2 = new Actor("wizard", 30, 8, ActorTypes.player);               // 2
                                                                       //
player3 = new Actor("cleric", 30, 11, ActorTypes.player);              // 2
                                                                       //
enemy = new Actor("goblin", 40, 10, ActorTypes.enemy);                 // 2
                                                                       //
enemy2 = new Actor("goblin", 40, 10, ActorTypes.enemy);                // 2
                                                                       //
enemy3 = new Actor("goblin", 40, 10, ActorTypes.enemy);                // 2
                                                                       //
player.grid = grid;                                                    // 2
                                                                       //
player.setMapCoordinate(0, 0);                                         // 2
                                                                       //
movementAction = new MovementAction(30);                               // 2
                                                                       //
console.log(movementAction);                                           // 2
                                                                       //
magicMissleEffect = new Effect([                                       // 2
  {                                                                    //
    dieCount: 1,                                                       // 32
    dieType: 4,                                                        // 32
    modifier: 1                                                        // 32
  }                                                                    //
], "damage", "magic");                                                 //
                                                                       //
magicMissileAction = new Action([magicMissleEffect, magicMissleEffect, magicMissleEffect], 120, [1, 3], ActionTypes.normal, "Cast Magic Missile");
                                                                       //
burningHandsEffect = new Effect([                                      // 2
  {                                                                    //
    dieCount: 3,                                                       // 37
    dieType: 6,                                                        // 37
    modifier: 0                                                        // 37
  }                                                                    //
], "damage", "fire");                                                  //
                                                                       //
burningHandsAction = new Action([burningHandsEffect], 0, ["cone", 15], ActionTypes.normal, "Cast Burning Hands");
                                                                       //
greatswordDamageEffect = new Effect([                                  // 2
  {                                                                    //
    dieCount: 2,                                                       // 40
    dieType: 6,                                                        // 40
    modifier: 4                                                        // 40
  }                                                                    //
], "damage", "slashing");                                              //
                                                                       //
greatswordAction = new Action([greatswordDamageEffect], 5, 1, ActionTypes.normal, "Attack with greatsword");
                                                                       //
player.addAction("greatsword", greatswordAction);                      // 2
                                                                       //
player.addAction("movement", movementAction);                          // 2
                                                                       //
player.showActions();                                                  // 2
                                                                       //
player.selectAction("greatsword");                                     // 2
                                                                       //
player.currentAction.setTarget(enemy);                                 // 2
                                                                       //
player.currentAction.resolve();                                        // 2
                                                                       //
player2.addAction("magicMissile", magicMissileAction);                 // 2
                                                                       //
player2.addAction("burningHands", burningHandsAction);                 // 2
                                                                       //
player2.showActions();                                                 // 2
                                                                       //
player2.selectAction("magicMissile");                                  // 2
                                                                       //
player2.currentAction.setTarget(enemy2);                               // 2
                                                                       //
player2.currentAction.resolve();                                       // 2
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=main.coffee.js.map
